package com.java.spring.mvc.model;

public enum Gender {
	MALE, FEMALE
}
