package com.java.infinite;

public enum Gender {

	MALE, FEMALE
}
