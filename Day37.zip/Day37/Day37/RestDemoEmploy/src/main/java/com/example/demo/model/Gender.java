package com.example.demo.model;

public enum Gender {
	
	MALE, FEMALE
}
