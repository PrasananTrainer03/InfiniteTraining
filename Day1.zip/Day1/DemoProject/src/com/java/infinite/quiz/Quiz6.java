package com.java.infinite.quiz;

public class Quiz6 {

	public static void main(String[] args) {
		int i=10;
		int j=++i;
		System.out.println(i + "  " +j);
	}
}
