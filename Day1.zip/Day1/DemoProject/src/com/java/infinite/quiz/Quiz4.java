package com.java.infinite.quiz;

public class Quiz4 {

	public static void main(String[] args) {
		byte b1=125;
		b1+=8;
		System.out.println(b1);
	}
}
