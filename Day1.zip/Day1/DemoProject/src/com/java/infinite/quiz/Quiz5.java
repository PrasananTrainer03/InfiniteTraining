package com.java.infinite.quiz;

public class Quiz5 {

	public static void main(String[] args) {
		char ch='A';
		ch++;
		int a=ch;
		System.out.println(a);
	}
}
