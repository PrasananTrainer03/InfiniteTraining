package com.java.infinite.quiz;

public class Quiz7 {

	public void show() {
		int[] a = new int[] {12,4,22,56,23};
		for (int i : a) {
			System.out.println(a);
		}
	}
	public static void main(String[] args) {
		new Quiz7().show();
	}
}
