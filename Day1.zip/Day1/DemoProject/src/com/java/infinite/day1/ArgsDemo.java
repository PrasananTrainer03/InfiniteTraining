package com.java.infinite.day1;

public class ArgsDemo {

	public static void main(String[] args) {
		String firstName = args[0];
		String lastName = args[1];
		System.out.println("First Name is  " +firstName);
		System.out.println("Last Name is   " +lastName);
	}
}
