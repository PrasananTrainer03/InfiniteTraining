package com.java.infinite.day1;

public class Demo1 {

	public static void main(String[] args) {
		String company = "Infinite";
		System.out.println("Company is  " +company);
	}
}
