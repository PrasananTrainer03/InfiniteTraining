package com.java.infinite.day1;

class Data {
	
	public void sai() {
		System.out.println("HI i am Madhav Sai Kumar...");
	}
	
	void naresh() {
		System.out.println("Hi I am Naresh...");
	}
	
	private void sravani() {
		System.out.println("Hi I am Sravani...");
	}
}

public class Demo {

	public static void main(String[] args) {
		Data obj = new Data();
		obj.sai();
		obj.naresh();
	}
}
