package com.java.jdbc.spring;

public enum Gender {
	
	MALE, FEMALE
}
