package infinite.SpringNameDemo;

import org.junit.Test;

import com.java.infinite.namedemo.App;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}
