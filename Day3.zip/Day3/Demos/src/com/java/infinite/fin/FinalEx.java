package com.java.infinite.fin;

final class Demo {
	final int x=12;
	
	void show() {
		System.out.println("X value is  " +x);
		// x=13; error as final variables cannot be modified
	}
}

public class FinalEx {

}
