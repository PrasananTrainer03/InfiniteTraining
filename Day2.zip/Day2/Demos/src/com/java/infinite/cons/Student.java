package com.java.infinite.cons;

public class Student {

	int sno;
	String name;
	double cgp;
	String city;
}
