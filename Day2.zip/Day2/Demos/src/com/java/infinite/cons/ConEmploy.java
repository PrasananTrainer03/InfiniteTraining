package com.java.infinite.cons;

public class ConEmploy {

	public static void main(String[] args) {
		Employ e1 = new Employ(1, "John", 92345);
		Employ e2 = new Employ(3, "Lavanya", 78234);
		
		System.out.println(e1);
		System.out.println(e2);
	}
}
