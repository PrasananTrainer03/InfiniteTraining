package com.java.infinite.quiz;

public class Quiz8 {

	private Quiz8() {
		System.out.println("Default Constructor...");
	}
	
	public static void main(String[] args) {
		new Quiz8();
	}
}
