package com.java.infinite.quiz;

public class Quiz5 {

	public static void main(String[] args) {
		int no=3;
		switch(no) {
		case 1 : 
			System.out.println("Hi");
		case 2: 
			System.out.println("Hello");
		case 3: 
			System.out.println("Who");
		case 4 : 
			System.out.println("Rahul");
		case 5 : 
			System.out.println("Malissa");
		case 6 : 
			System.out.println("Kiran");
		default : 
			System.out.println("Yashik");
		}
	}
}
