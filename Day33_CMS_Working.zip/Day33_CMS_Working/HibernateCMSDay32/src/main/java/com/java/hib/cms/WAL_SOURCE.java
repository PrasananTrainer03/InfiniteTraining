package com.java.hib.cms;

public enum WAL_SOURCE {
	
	PAYTM,CREDIT_CARD,DEBIT_CARD

}
