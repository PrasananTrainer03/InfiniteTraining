package com.java.hib.cms;

public enum OrderStatus {
	ACCEPTED, DENIED, PENDING
}
