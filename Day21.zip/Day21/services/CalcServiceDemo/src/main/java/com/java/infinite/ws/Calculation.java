package com.java.infinite.ws;

public class Calculation {

	public int sum(int x,int y) {
		return x+y;
	}
	
	public int sub(int x, int y) {
		return x-y;
	}
	
	public int mult(int x, int y) {
		return x*y;
	}
}
