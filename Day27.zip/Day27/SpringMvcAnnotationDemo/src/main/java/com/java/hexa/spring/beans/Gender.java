package com.java.hexa.spring.beans;

public enum Gender {
	MALE, FEMALE
}
