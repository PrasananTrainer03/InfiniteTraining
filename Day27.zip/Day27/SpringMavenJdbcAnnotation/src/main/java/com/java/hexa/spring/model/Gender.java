package com.java.hexa.spring.model;

public enum Gender {
	MALE, FEMALE
}
