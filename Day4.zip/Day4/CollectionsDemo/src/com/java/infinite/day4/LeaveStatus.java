package com.java.infinite.day4;

public enum LeaveStatus {

	PENDING, APPROVED, REJECTED
}
