package com.java.infinite.day4;

public class Ex1 {

	public static void main(String[] args) {
		String s1="Prasanna", s2="Rajesh";
		System.out.println(s2.compareTo(s1));
	}
}
