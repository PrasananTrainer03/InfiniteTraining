package com.java.infinite.day4;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetDemo2 {

	public static void main(String[] args) {
		Set s = new LinkedHashSet();
		s.add("Pavan");
		s.add("Sandhya");
		s.add("Nandhini");
		s.add("Naresh");
		s.add("Deepthi");
		s.add("Pavan");
		s.add("Sandhya");
		s.add("Nandhini");
		s.add("Naresh");
		s.add("Deepthi");
		s.add("Pavan");
		s.add("Sandhya");
		s.add("Nandhini");
		s.add("Naresh");
		s.add("Deepthi");
		s.add("Pavan");
		s.add("Sandhya");
		s.add("Nandhini");
		s.add("Naresh");
		s.add("Deepthi");
		s.add("Pavan");
		s.add("Sandhya");
		s.add("Nandhini");
		s.add("Naresh");
		s.add("Deepthi");
		s.add("Pavan");
		s.add("Sandhya");
		s.add("Nandhini");
		s.add("Naresh");
		s.add("Deepthi");
		System.out.println("Names are  ");
		for (Object ob : s) {
			System.out.println(ob);
		}
	}
}
