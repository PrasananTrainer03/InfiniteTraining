package com.java.infinite.day4;

public class Student {

	int sid;
	String name;
	double cgp;
	String city;
}

/*
 Create list of students and sort them based on Name, Cgp and City 

*/