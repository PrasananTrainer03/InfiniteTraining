package com.java.infinite.day4;

public enum LeaveType {

	EL, PL, ML
}
