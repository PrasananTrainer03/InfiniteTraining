public class Quiz12 {
    public static void main(String[] args) {
        System.out.println("5" +3+8);
        System.out.println("5 + 3" +8);
        System.out.println("5" + (3+8));
        Quiz12 obj = new Quiz12();
        System.out.println(obj);
        int[] a=new int[]{12,5,77,24,634,55};
        for(int i : a) {
            System.out.println(a);
        }
    }
}