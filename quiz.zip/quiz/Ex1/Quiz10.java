public class Quiz10 {
    public static void main(String[] args) {
        int x;
        System.out.println(x);
    }
}

