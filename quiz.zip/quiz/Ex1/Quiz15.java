public class Quiz15 {
    public static void main(String[] args) {
        int x=12;
        Integer p = x;

        //int y =(Integer)x;
        int y =Integer.valueOf(12);
        int p1 =Integer.valueOf(p);
    }
}