public class Prog16 {
    public static void main(String[] args) {
        Integer n = Integer.valueOf(5000);
        Integer p = new Integer(5000);
    int a = n.intValue();

    System.out.println(a); 
    System.out.println(n);
    System.out.println(p); 
    }
}