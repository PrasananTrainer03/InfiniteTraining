public class Prog13 {
    public static void main(String[] args) {
        Integer intObj1 = Integer.valueOf(100);
        System.out.println(intObj1);
        Integer intObj2 = Integer.valueOf("1234");
        System.out.println(intObj2);
        
        Double doubleObj1 = Double.valueOf(10.45);
        System.out.println(doubleObj1);
        
        Double doubleObj2 = Double.valueOf("1234.60");
        System.out.println(doubleObj2);
        
        Character charObj1 = Character.valueOf('A');
        System.out.println(intObj1);
        System.out.println(intObj2);
        System.out.println(doubleObj1);
        System.out.println(doubleObj2);
        System.out.println(charObj1);
    }
}