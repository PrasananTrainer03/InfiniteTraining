public class Test1 {
    public static void main(String[] args) {
        byte b1=-100;
        int i1=b1;
        System.out.println(b1);

        i1=386;
        b1=(byte)i1;
        System.out.println(b1);
    }
}