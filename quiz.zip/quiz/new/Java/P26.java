import java.util.ArrayList;
public class P26 {
    public static void main(String[] args) {
        int[] a=new int[]{12,5,3,23,45};
        System.out.println(a);
        for(int i : a) {
            System.out.println(a);
        }
        // ArrayList<Integer> alist = new ArrayList<>();
        // alist.add(new Integer(522));
        // alist.add(new Integer(55));
        // alist.add(new Integer(42));
        // alist.add(new Integer(78));
        // alist.add(new Integer(33));
        // alist.add(new Integer(89));
        // System.out.println(alist);
        // System.out.println("For Loop");
        // for(Integer i : alist) {
        //     System.out.println(alist);
        // }
    }
}