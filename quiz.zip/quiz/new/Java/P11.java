public class P11 {
    public static void main(String[] args) {
        System.out.println( 5 + 3+"45");
        System.out.println("13" + "$" + 3);
        System.out.println("" +13 + (5 + 3));
        System.out.println("" +13 + 5 + 3);
    }
}