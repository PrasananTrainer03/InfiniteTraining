
public class P34 extends String {
    public static void main(String[] args) {
        System.out.println("Strings are Immutable...");
    }
}