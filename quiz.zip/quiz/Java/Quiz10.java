public class Quiz10 {
    public static void main(String[] args) {
        int i=10;
      byte b = (Byte)10;
        System.out.println(b);
    }
}